import random

def bmi():
	'''
	BMI Calculator given some user input
	'''
	try:
		weight = float(input("Enter weight in kilograms: "))
		height = float(input("Enter height in metres:    "))

		bmi = weight / (height*height)
		label = ''

		if (bmi < 18.5):
		    label = 'underweight'
		elif bmi < 25:
		    label = 'normal'
		elif bmi < 30:
		    label = 'overweight'
		elif bmi < 35:
		    label = 'obese'
		else:
		    label = 'extremely obese'

		print("Your BMI is %.1f (%s)" % (bmi, label))
	except:
		print("Sorry, invalid numbers entered.")

def lottery():
	'''
	Draws five unique numbers
	'''
	result = []
	while len(result) < 5:
		new_num = random.randint(1,90)
		if new_num not in result:
			result.append(new_num)

	print('Lotto results:', result)

def stats():
	'''
	Ask the user to enter a sentence and print out the following statistics:
    Number of characters
    Number of alphabetical letters (a-z, A-Z)
    Number of vowels
    Number of words
	'''
	sentence = input("Enter a sentence: ")
	characters = len(sentence)
	letters = 0
	vowels = 0
	words = 1
	for char in sentence:
		if char.isalpha():
			letters +=1
		if char in 'aeiouAEIOU':
			vowels += 1
		if char == ' ':
			words += 1
	print("characters:", characters)
	print("letters:   ", letters)
	print("vowels:    ", vowels)
	print("words:     ", words)

def my_feature():
    print('Not implemented yet')

random.random()
