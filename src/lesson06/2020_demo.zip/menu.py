import tools as T

def print_menu():
	''' 
	Prints the menu
	'''
	print("Welcome to my menu-driven app, choose one of the following:")
	print("1. BMI calculator")
	print("2. Lottery draw")
	print("3. Word counter")
	print("4. Your feature")
	print("5. Quit")

while True:
	print_menu()
	choice = input("select an option: ")
	if (choice == '1'):
		T.bmi()
	elif (choice == '2'):
		T.lottery()
	elif (choice == '3'):
		T.stats()
	elif (choice == '4'):
		T.my_feature()
	elif (choice == '5'):
		break
	else:
		print("Invalid input, please choose an option from the menu!")
